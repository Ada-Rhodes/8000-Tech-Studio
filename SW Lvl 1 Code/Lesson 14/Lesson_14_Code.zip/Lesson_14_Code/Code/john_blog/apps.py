from django.apps import AppConfig


class SonaStudyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'john_blog'
